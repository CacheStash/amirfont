import React, { useState } from 'react';
import { Plus, Loader2 } from 'lucide-react';
import { supabase } from '../../lib/supabase';

// Definisi tipe untuk hasil API agar TypeScript tidak error
interface UploadResponse {
  success: boolean;
  fileName: string;
  url: string;
  error?: string;
}

// Menambahkan props initialData & onSuccess untuk fitur EDIT
const FontUploadForm = ({ initialData, onSuccess }: { initialData?: any, onSuccess?: () => void }) => {
  // 1. State untuk Form (Diambil dari initialData jika sedang mode EDIT)
  const [fontName, setFontName] = useState(initialData?.name || '');
  const FONT_TAGS_LIBRARY = [
    // 1. Klasifikasi Utama & Teknis
    "Blackletter", "Calligraphy", "Dingbats", "Display", "Experimental", "Fraktur", "Handwritten",
    "Layered", "Monospace", "OpenType Features", "Pixel", "Rough", "Rustic", "Sans Serif", "Script",
    "Serif", "Signature", "Slab Serif", "Stencil", "Text", "Variable Font",

    // 2. Sub-Klasifikasi Serif & Sans
    "Didone", "Didot", "Garalde", "Geometric Sans", "Glyphic", "Grotesk", "Grotesque", "Humanist Sans",
    "Humanist Serif", "Modern Serif", "Neo-Grotesque", "Old Style", "Rustic Serif", "Square Sans",
    "Transitional", "Tuscan", "Wedge Serif",

    // 3. Sistem Layered, Chromatic & 3D
    "Bevel", "Chromatic", "Color Font", "Drop Shadow", "Embossed", "Extrude", "Fill Layer", "Gradient",
    "Hatch", "Inline", "Layered System", "Multilayer", "Offset", "Ornamental Layer", "Outline", "Ribbon",
    "Shadow", "Staggered", "Volume",

    // 4. Era, Historis & Vintage Heritage
    "1800s", "1900s", "1920s", "1930s", "1950s", "1960s", "1970s", "1980s", "1990s", "50s", "60s",
    "70s", "80s", "90s", "Americana", "Antique", "Art Deco", "Art Nouveau", "Baroque", "Bauhaus",
    "Circus", "Colonial", "Cyberpunk", "Early American", "Edwardian", "Futuristic", "Gilded Age",
    "Industrial", "Medieval", "Mid-Century", "Mid-Century Modern", "Nostalgic", "Old West", "Psychedelic",
    "Renaissance", "Retro", "Steampunk", "Victorian", "Vintage", "Western", "Wild West", "Y2K",

    // 5. Karakteristik Fisik, Geometri & Outline
    "Clean", "Condensed", "Distressed", "Expanded", "Extra Bold", "Heavy", "High Contrast", "Inktraps",
    "Light", "Low Contrast", "Medium", "Narrow", "Oblique", "Pencil Stroke", "Reverse Contrast", "Ribbon Cut",
    "Rounded", "Rough Edges", "Semi Bold", "Sharp", "Soft Edges", "Spurred", "Stamp Effect", "Swash",
    "Tall", "Textured", "Thin", "Tight Kerning", "Wide",

    // 6. Penggunaan, Vibe & Mood Industri
    "Acid", "Advertising", "Apparel", "Archival", "Authoritative", "Badges", "Beer Label", "Beverage",
    "Bold Header", "Book Cover", "Bootleg", "Branding", "Brutalism", "Cafe Menu", "Casual", "Chicano",
    "Chiseled", "Classic", "Coffee Shop", "Commercial", "Corporate", "Craft", "Cyber", "Editorial",
    "Elegant", "Emblem", "Esoteric", "Exclusive", "Fairground", "Fashion", "Film Poster", "Gothic",
    "Hardcore", "Header", "Heritage", "Hero Title", "High End", "Horror", "Label Design", "Letterpress",
    "Logotype", "Luxury", "Magazine", "Masculine", "Minimalist", "Monogram", "Motorcycle", "Music Poster",
    "Mystical", "Neoclassical", "Packaging", "Period Piece", "Playful", "Postage Stamp", "Poster",
    "Premium", "Prohibition", "Pub Sign", "Saloon", "Signage", "Sign Painting", "Streetwear", "Subcultural",
    "Tattoo", "Theater", "Tiki", "Timeless", "Title", "Typography", "Urban", "Whiskey Label", "Woodcut", "Wood Type"
  ].sort((a, b) => a.localeCompare(b, undefined, { sensitivity: 'base' }));
  
  const [description, setDescription] = useState(initialData?.description || '');
  const [tags, setTags] = useState(initialData?.tags?.join(', ') || ''); 
  
  // Matriks Harga sesuai EULA 2026 (User Seats, Traffic Tiers, & Corporate)
  const [licensePrices, setLicensePrices] = useState(initialData?.license_prices || {
    desktop: { solo: 0, team: 0, studio: 0, enterprise: 0 },
    logo_branding: { personal: 0, solo: 0, team: 0, studio: 0, enterprise: 0 },
    social_web: { small_50k: 0, medium_500k: 0, large_5m: 0, enterprise_unlimited: 0 },
    app: { solo: 0, team: 0, studio: 0, enterprise: 0 },
    broadcast: { solo: 0, team: 0, studio: 0, enterprise: 0 },
    server: { solo: 0, team: 0, studio: 0, enterprise: 0 },
    corporate_full_suite: 0
  });

  const [price, setPrice] = useState(initialData?.price?.toString() || ''); 

  // Handler untuk update harga
  const updatePrice = (category: string, subKey: string | null, value: string) => {
    const numValue = parseFloat(value) || 0;
    setLicensePrices((prev: any) => {
      if (category === 'corporate_full_suite') {
        return { ...prev, corporate_full_suite: numValue };
      }
      return {
        ...prev,
        [category]: { 
          ...(prev[category as keyof typeof prev] as object), 
          [subKey!]: numValue 
        }
      };
    });
  };

  const [fontFiles, setFontFiles] = useState<File[]>([]);
  const [trialFile, setTrialFile] = useState<File | null>(null);
  const [previewImages, setPreviewImages] = useState<File[]>([]);
  const [existingFontFiles, setExistingFontFiles] = useState<string[]>(initialData?.font_files || []);
  const [existingPreviewImages, setExistingPreviewImages] = useState<string[]>(initialData?.preview_images || []);
  const [existingTrialFile, setExistingTrialFile] = useState<string>(initialData?.trial_file_url || '');
  const [isUploading, setIsUploading] = useState(false);
  const [driveResults, setDriveResults] = useState<{images: any[], fonts: any[], trial: any[]} | null>(null);
  const [isSearchingDrive, setIsSearchingDrive] = useState(false);
  
  // Layer & Primary States
  const [primaryFontIndex, setPrimaryFontIndex] = useState<number>(initialData?.metadata?.primary_font_index || 0);
  const [isLayered, setIsLayered] = useState<boolean>(initialData?.metadata?.is_layered || false);
  const [layerFontIndices, setLayerFontIndices] = useState<number[]>(initialData?.metadata?.layer_font_indices || []);

  const [draggedImgIndex, setDraggedImgIndex] = useState<number | null>(null);

  // Helper Autocomplete untuk Classification Tags (Root Scope)
  const currentTagQuery = tags.split(',').pop()?.trimStart() || '';
  
  const activeSuggestion = currentTagQuery.length >= 1
    ? FONT_TAGS_LIBRARY.find(tag => tag.toLowerCase().startsWith(currentTagQuery.toLowerCase())) || ''
    : '';

  const ghostSuffix = (activeSuggestion && activeSuggestion.toLowerCase().startsWith(currentTagQuery.toLowerCase()))
    ? activeSuggestion.slice(currentTagQuery.length)
    : '';

  const handleTagKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if ((e.key === 'Tab' || e.key === 'Enter') && activeSuggestion) {
      e.preventDefault();
      const parts = tags.split(',');
      parts[parts.length - 1] = (parts[parts.length - 1].startsWith(' ') ? ' ' : '') + activeSuggestion;
      setTags(parts.join(',') + ', ');
    }
  };

  const handleDragStart = (index: number) => setDraggedImgIndex(index);
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
  };
  const handleDrop = (index: number) => {
    if (draggedImgIndex === null) return;
    const newArray = [...existingPreviewImages];
    const draggedItem = newArray[draggedImgIndex];
    newArray.splice(draggedImgIndex, 1);
    newArray.splice(index, 0, draggedItem);
    setExistingPreviewImages(newArray);
    setDraggedImgIndex(null);
  };

  const handleSelectAllDrive = (type: 'fonts' | 'previews') => {
    if (!driveResults) return;
    if (type === 'fonts') {
      const unselected = driveResults.fonts.filter(f => !existingFontFiles.includes(f.id));
      setExistingFontFiles(prev => [...prev, ...unselected.map(f => f.id)]);
    } else {
      const unselected = driveResults.images.filter(img => !existingPreviewImages.includes(img.id));
      if (existingPreviewImages.length + previewImages.length + unselected.length > 20) return alert("Maksimal 20 gambar!");
      setExistingPreviewImages(prev => [...prev, ...unselected.map(img => img.id)]);
    }
  };

  const fetchFromDrive = async () => {
    if (!fontName) return alert("Isi nama font dulu!");
    setIsSearchingDrive(true);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      const res = await fetch(`/api/admin/drive-search?q=${encodeURIComponent(fontName)}`, {
        headers: { 'Authorization': `Bearer ${session?.access_token}` }
      });
      const data = (await res.json()) as { images: any[]; fonts: any[]; trial: any[]; error?: string };
      
      if (data.error) {
        alert("Drive Error: " + data.error);
        setDriveResults({ images: [], fonts: [], trial: [] });
      } else {
        // Natural Sort Client-side Safety
        const sortedImages = (data.images || []).sort((a, b) => 
          (a.name || '').localeCompare(b.name || '', undefined, { numeric: true, sensitivity: 'base' })
        );
        const sortedFonts = (data.fonts || []).sort((a, b) => 
          (a.name || '').localeCompare(b.name || '', undefined, { numeric: true, sensitivity: 'base' })
        );
        const sortedTrial = (data.trial || []).sort((a, b) => 
          (a.name || '').localeCompare(b.name || '', undefined, { numeric: true, sensitivity: 'base' })
        );

        setDriveResults({
          images: sortedImages,
          fonts: sortedFonts,
          trial: sortedTrial
        });
      }
    } catch (err) { 
      alert("Gagal koneksi ke Worker"); 
    } finally { 
      setIsSearchingDrive(false); 
    }
  };

  React.useEffect(() => {
    if (initialData) {
      setFontName(initialData.name || '');
      setDescription(initialData.description || '');
      setPrice(initialData.price?.toString() || '');
      setLicensePrices(initialData.license_prices || licensePrices);
      setTags(initialData.tags?.join(', ') || '');
      setExistingFontFiles(initialData.font_files || []);
      setExistingPreviewImages(initialData.preview_images || []);
      setExistingTrialFile(initialData.trial_file_url || '');
      setPrimaryFontIndex(initialData?.metadata?.primary_font_index || 0);
      setIsLayered(initialData?.metadata?.is_layered || false);
      setLayerFontIndices(
        initialData?.metadata?.layer_font_indices || 
        (initialData?.font_files ? initialData.font_files.map((_: any, i: number) => i) : [])
      );
    }
  }, [initialData]);

  const deleteFromR2 = async (fileName: string) => {
    if (!fileName || (/^[a-zA-Z0-9_-]{25,}$/.test(fileName) && !fileName.includes('.'))) return;
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) return;
      await fetch(`/api/admin/delete/${encodeURIComponent(fileName)}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${session.access_token}` }
      });
    } catch (err) {
      console.error("Gagal menghapus file dari R2:", err);
    }
  };

  const removeExistingFont = async (index: number) => {
    const fileToRemove = existingFontFiles[index];
    if (fileToRemove) {
      await deleteFromR2(fileToRemove);
    }
    setExistingFontFiles(prev => prev.filter((_, i) => i !== index));
  };

  const toggleLayerIndex = (idx: number) => {
    setLayerFontIndices(prev => {
      if (prev.includes(idx)) {
        return prev.filter(i => i !== idx);
      } else {
        return [...prev, idx].sort((a, b) => a - b);
      }
    });
  };

  const removeExistingPreview = (index: number) => {
    setExistingPreviewImages(prev => prev.filter((_, i) => i !== index));
  };
 
  const handleDropFiles = (e: React.DragEvent, type: 'fonts' | 'previews') => {
    e.preventDefault();
    e.stopPropagation();
    const files = Array.from(e.dataTransfer.files);
    
    if (type === 'fonts') {
      const filtered = files.filter(f => f.name.endsWith('.ttf') || f.name.endsWith('.otf') || f.name.endsWith('.woff2'));
      setFontFiles(prev => [...prev, ...filtered]);
    } else {
      if (previewImages.length + files.length > 20) return alert("Maksimal 20 gambar!");
      setPreviewImages(prev => [...prev, ...files]);
    }
  };

  // Fungsi upload helper ke R2
  const uploadToR2 = async (files: File[]) => {
    const uploadedUrls = [];
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) throw new Error("Akses ditolak. Silakan login kembali.");

    for (const file of files) {
      try {
        const timestamp = Date.now();
        const cleanFileName = file.name.replace(/\s+/g, '_');
        const uniqueFileName = `${timestamp}-${cleanFileName}`;

        const res = await fetch(`/api/admin/upload/${uniqueFileName}`, { 
          method: 'PUT', 
          headers: {
            'Authorization': `Bearer ${session.access_token}`,
            'Content-Type': file.type
          },
          body: file 
        });

        if (!res.ok) {
          const errorData = (await res.json()) as { error?: string };
          throw new Error(errorData.error || `Server Error: ${res.status}`);
        }

        const data = (await res.json()) as UploadResponse;
        if (data.success && data.fileName) {
          uploadedUrls.push(data.fileName);
        } else {
          throw new Error('Upload gagal tanpa alasan');
        }

      } catch (err: any) {
        console.error("Upload error detail:", err);
        throw new Error(`Gagal mengunggah ${file.name}: ${err.message}`);
      }
    }
    return uploadedUrls;
  };

  // Handler Upload & Save
  const handleSaveProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!initialData && fontFiles.length === 0 && existingFontFiles.length === 0) {
      return alert("Upload file font dulu (Local atau Drive)!");
    }
    if (!fontName || !price) return alert("Lengkapi data!");

    setIsUploading(true);
    try {
      const uploadedFontUrls = await uploadToR2(fontFiles);
      const uploadedPreviewUrls = await uploadToR2(previewImages);

      let uploadedTrialUrl = existingTrialFile;
      if (trialFile) {
        const trialResult = await uploadToR2([trialFile]);
        uploadedTrialUrl = trialResult[0];
      }

      const totalFontCount = existingFontFiles.length + uploadedFontUrls.length;

      const payload = {
        name: fontName,
        price: parseFloat(price),
        price_web: licensePrices.social_web.small_50k,
        price_app: licensePrices.app.solo,
        license_prices: licensePrices,
        description: description,
        tags: tags.split(',').map((t: string) => t.trim()).filter((t: string) => t !== ""),
        font_files: [...existingFontFiles, ...uploadedFontUrls],
        preview_images: [...existingPreviewImages, ...uploadedPreviewUrls],
        trial_file_url: uploadedTrialUrl,
        has_trial: uploadedTrialUrl !== '',
        metadata: {
          ...initialData?.metadata,
          primary_font_index: primaryFontIndex,
          is_layered: isLayered,
          layer_font_indices: isLayered 
            ? (layerFontIndices.length > 0 ? layerFontIndices : Array.from({ length: totalFontCount }, (_, i) => i))
            : []
        }
      };

      if (initialData?.id) {
        const { error: dbError } = await supabase.from('fonts').update(payload).eq('id', initialData.id);
        if (dbError) throw dbError;
        alert("Font berhasil diupdate!");
      } else {
        const { error: dbError } = await supabase.from('fonts').insert([payload]);
        if (dbError) throw dbError;
        alert("Gokil! Font berhasil dipublikasikan.");
      }
      
      onSuccess?.();
    } catch (err: any) {
      alert("Error: " + err.message);
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <form className="space-y-6" onSubmit={handleSaveProduct}>
      <div className="grid grid-cols-2 gap-6">
        <div className="space-y-2">
          <label className="block font-bold text-xs uppercase tracking-wider text-gray-500">Font Name</label>
          <input 
            type="text" 
            value={fontName}
            onChange={(e) => setFontName(e.target.value.toUpperCase())}
            className="w-full border border-black p-3 outline-none font-normal uppercase text-xl focus:bg-yellow-50 transition-colors" 
            placeholder="E.G. ROYAL GRANDE"
            required
          />
          <button 
            type="button" 
            onClick={fetchFromDrive}
            disabled={isSearchingDrive}
            className="text-[9px] bg-blue-600 text-white px-3 py-1 font-bold uppercase hover:bg-blue-700 disabled:bg-gray-400"
          >
            {isSearchingDrive ? "Searching..." : "⚡ Sync Drive"}
          </button>
        </div>
        <div className="space-y-2">
          <label className="block font-bold text-xs uppercase tracking-wider text-gray-500">Basic Price ($)</label>
          <input 
            type="number" 
            required
            value={price}
            onChange={(e) => {
              const val = e.target.value;
              setPrice(val);
              const base = parseFloat(val) || 0;
              const calc = (m: number) => m > 0 ? (m === 1 ? base : Math.floor(base * m)) : 0;
              
              setLicensePrices({
                desktop: { solo: calc(1), team: calc(3), studio: calc(7), enterprise: calc(15) },
                social_web: { small_50k: calc(1), medium_500k: calc(3), large_5m: calc(7), enterprise_unlimited: calc(15) },
                logo_branding: { personal: calc(2.5), solo: calc(5), team: calc(10), studio: calc(20), enterprise: calc(30) },
                app: { solo: calc(5), team: calc(12), studio: calc(25), enterprise: calc(55) },
                server: { solo: calc(5), team: 0, studio: calc(25), enterprise: calc(50) },
                broadcast: { solo: calc(5), team: 0, studio: calc(25), enterprise: calc(50) },
                corporate_full_suite: calc(150.0)
              });
            }}
            className="w-full border border-black p-3 outline-none focus:bg-yellow-50" 
            placeholder="25" 
          />
        </div>
      </div>

      {/* PRICING PREVIEW & TAGS INPUT */}
      <div className="grid grid-cols-2 gap-6">
        <div className="p-4 bg-gray-50 border border-black text-[10px] space-y-1 leading-tight">
          <p className="font-bold uppercase border-b border-black mb-2 text-black tracking-widest">License Preview (Solo/Base)</p>
          <div className="grid grid-cols-2 gap-x-4 gap-y-1 font-bold uppercase text-gray-600">
            <div className="flex items-center gap-1">
              <span>Desktop: $</span>
              <input 
                type="number" 
                value={licensePrices.desktop.solo} 
                onChange={(e) => updatePrice('desktop', 'solo', e.target.value)}
                className="bg-transparent border-none p-0 w-full font-bold focus:outline-none"
              />
            </div>
            <div className="flex items-center gap-1">
              <span>Social/Web: $</span>
              <input 
                type="number" 
                value={licensePrices.social_web.small_50k} 
                onChange={(e) => updatePrice('social_web', 'small_50k', e.target.value)}
                className="bg-transparent border-none p-0 w-full font-bold focus:outline-none"
              />
            </div>
            <div className="flex items-center gap-1">
              <span>Logo: $</span>
              <input 
                type="number" 
                value={licensePrices.logo_branding.solo} 
                onChange={(e) => updatePrice('logo_branding', 'solo', e.target.value)}
                className="bg-transparent border-none p-0 w-full font-bold focus:outline-none"
              />
            </div>
            <div className="flex items-center gap-1">
              <span>App: $</span>
              <input 
                type="number" 
                value={licensePrices.app.solo} 
                onChange={(e) => updatePrice('app', 'solo', e.target.value)}
                className="bg-transparent border-none p-0 w-full font-bold focus:outline-none"
              />
            </div>
            <div className="flex items-center gap-1">
              <span>Broadcast: $</span>
              <input 
                type="number" 
                value={licensePrices.broadcast.solo} 
                onChange={(e) => updatePrice('broadcast', 'solo', e.target.value)}
                className="bg-transparent border-none p-0 w-full font-bold focus:outline-none"
              />
            </div>
            <div className="flex items-center gap-1">
              <span>Server: $</span>
              <input 
                type="number" 
                value={licensePrices.server.solo} 
                onChange={(e) => updatePrice('server', 'solo', e.target.value)}
                className="bg-transparent border-none p-0 w-full font-bold focus:outline-none"
              />
            </div>
          </div>
          <div className="mt-1 pt-1 border-t border-black border-dotted flex items-center gap-1">
            <span>Corporate (All-in): $</span>
            <input 
              type="number" 
              value={licensePrices.corporate_full_suite} 
              onChange={(e) => updatePrice('corporate_full_suite', null, e.target.value)}
              className="bg-transparent border-none p-0 w-full font-bold focus:outline-none"
            />
          </div>
        </div>

        {/* INPUT CLASSIFICATION TAGS DENGAN SMART AUTOCOMPLETE */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <label className="block font-bold text-xs uppercase tracking-wider text-gray-500">
              Tags (Separated by Comma)
            </label>
            {activeSuggestion && (
              <span className="text-[9px] uppercase font-mono font-bold text-black bg-yellow-300 px-1 border border-black animate-pulse">
                [TAB]/[ENTER]: "{activeSuggestion}"
              </span>
            )}
          </div>
          <div className="relative w-full border border-black focus-within:bg-yellow-50 transition-colors bg-white">
            {/* Ghost text background overlay */}
            <div 
              className="absolute inset-0 p-3 font-normal text-base pointer-events-none select-none overflow-hidden whitespace-pre flex items-center"
              aria-hidden="true"
            >
              <span className="opacity-0">{tags}</span>
              <span className="opacity-30 italic">{ghostSuffix}</span>
            </div>

            {/* Main Interactive Input */}
            <input 
              type="text" 
              value={tags}
              onChange={(e) => setTags(e.target.value)}
              onKeyDown={handleTagKeyDown}
              className="relative z-10 w-full p-3 bg-transparent outline-none font-normal text-base placeholder:text-gray-400 text-black" 
              placeholder="Variable, Serif, Display" 
            />
          </div>
        </div>
      </div>

      {/* LAYERED FONT SYSTEM CHECKBOX */}
      <div className="p-4 border border-black bg-gray-50 flex items-center justify-between">
        <div>
          <label className="font-bold text-xs uppercase tracking-wider text-black block cursor-pointer" htmlFor="isLayeredCheckboxSubqi">
            Layered Font System
          </label>
          <p className="text-[10px] text-gray-500 mt-0.5">
            Enable chromatic/multi-layer artifact composite stacking in TypeTester.
          </p>
        </div>
        <input 
          id="isLayeredCheckboxSubqi"
          type="checkbox" 
          checked={isLayered} 
          onChange={(e) => setIsLayered(e.target.checked)} 
          className="w-5 h-5 accent-black cursor-pointer"
        />
      </div>

      <div className="space-y-2">
        <label className="block font-bold text-xs uppercase tracking-wider text-gray-500">Font Binaries (Multiples .ttf, .otf)</label>
        <div 
          onDragOver={handleDragOver}
          onDrop={(e) => handleDropFiles(e, 'fonts')}
          className="border-2 border-dashed border-black p-6 text-center hover:bg-gray-50 transition-colors cursor-pointer group bg-white"
        >
          <input
            type="file" multiple accept=".ttf,.otf,.woff2" className="hidden" id="fontFiles" 
            onChange={(e) => setFontFiles(prev => [...prev, ...Array.from(e.target.files || [])])}
          />
          <label htmlFor="fontFiles" className="cursor-pointer">
            <Plus className="mx-auto mb-2" />
            <p className="text-[10px] font-bold uppercase tracking-widest text-gray-400">Drag & Drop or Click to Add Fonts</p>
          </label>

          {(existingFontFiles.length > 0 || fontFiles.length > 0) && (
            <div className="mt-4 flex flex-wrap gap-2 justify-center">
              {existingFontFiles.map((f, i) => {
                const isPartOfLayer = !isLayered || layerFontIndices.includes(i);
                return (
                  <span 
                    key={`ex-f-${i}`} 
                    className={`border text-[9px] px-2.5 py-1.5 uppercase flex items-center gap-2 transition-all select-none ${primaryFontIndex === i ? 'bg-black text-white border-black' : 'bg-gray-100 text-black border-black'}`}
                  >
                    <button
                      type="button"
                      onClick={() => setPrimaryFontIndex(i)}
                      className="hover:scale-110 transition-transform"
                      title="Set as Primary Font"
                    >
                      {primaryFontIndex === i ? <span className="text-yellow-400">★</span> : <span className="opacity-30 hover:opacity-100">☆</span>}
                    </button>

                    <span>{f.includes('-') ? f.replace(/^\d{10,}-/, '') : f}</span>

                    {/* Toggle Layer vs Pairing */}
                    {isLayered && (
                      <button
                        type="button"
                        onClick={(e) => { e.stopPropagation(); toggleLayerIndex(i); }}
                        className={`px-2 py-0.5 text-[8px] font-mono font-bold uppercase transition-all border ${
                          isPartOfLayer 
                            ? (primaryFontIndex === i ? 'bg-white text-black border-white' : 'bg-black text-white border-black')
                            : (primaryFontIndex === i ? 'bg-transparent text-white/70 border-white/40 hover:text-white' : 'bg-white text-gray-700 border-gray-400 hover:text-black hover:border-black')
                        }`}
                        title={isPartOfLayer ? "Click to set as Pairing" : "Click to include in Layered Stack"}
                      >
                        {isPartOfLayer ? '● LAYER' : '○ PAIRING'}
                      </button>
                    )}

                    <button type="button" onClick={(e) => { e.stopPropagation(); removeExistingFont(i); }} className="text-red-500 font-bold hover:scale-125 transition-transform ml-1">×</button>
                  </span>
                );
              })}

              {fontFiles.map((f, i) => {
                const combinedIdx = existingFontFiles.length + i;
                const isPartOfLayer = !isLayered || layerFontIndices.includes(combinedIdx);
                return (
                  <span 
                    key={`new-f-${i}`} 
                    className={`text-[9px] px-2.5 py-1.5 uppercase flex items-center gap-2 transition-all select-none ${primaryFontIndex === combinedIdx ? 'bg-black text-white border border-black' : 'bg-gray-800 text-gray-300 border border-transparent'}`}
                  >
                    <button
                      type="button"
                      onClick={() => setPrimaryFontIndex(combinedIdx)}
                      className="hover:scale-110 transition-transform"
                      title="Set as Primary Font"
                    >
                      {primaryFontIndex === combinedIdx ? <span className="text-yellow-400">★</span> : <span className="opacity-30 hover:opacity-100">☆</span>}
                    </button>

                    <span>{f.name}</span>

                    {isLayered && (
                      <button
                        type="button"
                        onClick={(e) => { e.stopPropagation(); toggleLayerIndex(combinedIdx); }}
                        className={`px-2 py-0.5 text-[8px] font-mono font-bold uppercase transition-all border ${
                          isPartOfLayer 
                            ? 'bg-white text-black border-white' 
                            : 'bg-black text-gray-300 border-gray-600 hover:text-white hover:border-white'
                        }`}
                        title={isPartOfLayer ? "Click to set as Pairing" : "Click to include in Layered Stack"}
                      >
                        {isPartOfLayer ? '● LAYER' : '○ PAIRING'}
                      </button>
                    )}

                    <button 
                      type="button" 
                      onClick={(e) => { e.stopPropagation(); setFontFiles(prev => prev.filter((_, idx) => idx !== i)); }} 
                      className="text-red-400 font-bold hover:text-red-200 transition-colors ml-1"
                    >
                      ×
                    </button>
                  </span>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* TRIAL FILE */}
      <div className="space-y-2">
        <label className="block font-bold text-xs uppercase tracking-wider text-gray-500">
          Trial / Demo Version (.zip / .ttf)
        </label>
        <div className="border-2 border-black p-4 bg-yellow-50/50 relative">
          <input 
            type="file" 
            accept=".zip,.ttf,.otf"
            onChange={(e) => setTrialFile(e.target.files?.[0] || null)}
            className="w-full text-[10px] font-mono cursor-pointer"
          />
          {(existingTrialFile || trialFile) && (
            <div className="flex justify-between items-center mt-2">
              <p className="text-[9px] font-bold uppercase text-black">
                STATUS: {trialFile ? `NEW: ${trialFile.name}` : `EXISTING: ${existingTrialFile}`}
              </p>
              {trialFile && (
                <button 
                  type="button" 
                  onClick={() => setTrialFile(null)}
                  className="text-red-500 font-bold text-[10px] hover:underline"
                >
                  CANCEL NEW ×
                </button>
              )}
              {existingTrialFile && !trialFile && (
                <button 
                  type="button" 
                  onClick={async () => {
                    await deleteFromR2(existingTrialFile);
                    setExistingTrialFile('');
                  }}
                  className="text-red-500 font-bold text-[10px] hover:underline"
                >
                  REMOVE EXISTING ×
                </button>
              )}
            </div>
          )}
        </div>
      </div>

      {/* PREVIEW IMAGES */}
      <div className="space-y-2">
        <label className="block font-bold text-xs uppercase tracking-wider text-gray-500">Preview Images (Max 20)</label>
        <div 
          onDragOver={handleDragOver}
          onDrop={(e) => handleDropFiles(e, 'previews')}
          className="grid grid-cols-4 md:grid-cols-6 gap-2 border-2 border-black p-4 bg-gray-100"
        >
          {Array.isArray(driveResults?.images) && driveResults.images.filter(img => !existingPreviewImages.includes(img.id)).length > 0 && (
             <div className="col-span-full flex justify-between items-center bg-blue-100 p-1 px-2 border border-blue-300">
               <span className="text-[8px] font-bold text-blue-700 uppercase">Drive Images</span>
               <button type="button" onClick={() => handleSelectAllDrive('previews')} className="text-[7px] bg-blue-600 text-white px-2 py-0.5 font-bold uppercase hover:bg-black transition-colors">Select All</button>
             </div>
          )}

          {Array.isArray(driveResults?.images) && driveResults.images.filter(img => !existingPreviewImages.includes(img.id)).map((img, i) => (
            <div key={`dr-p-${i}`} className="aspect-square bg-blue-50 border border-blue-200 relative group overflow-hidden">
              <img src={img.url} className="w-full h-full object-cover" alt="drive" />
              <button
                type="button"
                onClick={() => setExistingPreviewImages(prev => [...prev, img.id])}
                className="absolute inset-0 bg-blue-600/90 text-white opacity-0 group-hover:opacity-100 flex items-center justify-center font-bold text-[8px]"
              >
                USE DRIVE FILE
              </button>
              <div className="absolute top-0 left-0 bg-blue-600 text-white text-[7px] px-1">DRIVE</div>
            </div>
          ))}

          {existingPreviewImages.map((url, i) => (
            <div 
              key={`ex-p-${i}`} 
              draggable
              onDragStart={() => handleDragStart(i)}
              onDragOver={handleDragOver}
              onDrop={() => handleDrop(i)}
              className={`aspect-square bg-white border border-black relative group overflow-hidden cursor-move transition-opacity ${draggedImgIndex === i ? 'opacity-30' : 'opacity-100'}`}
            >
              <img src={`/api/images/${url}`} className="w-full h-full object-cover" alt="preview" />
              <button 
                type="button" 
                onClick={() => removeExistingPreview(i)}
                className="absolute inset-0 bg-red-600/80 text-white opacity-0 group-hover:opacity-100 flex items-center justify-center font-bold"
              >
                DELETE
              </button>
            </div>
          ))}
          
          {previewImages.map((file, i) => (
            <div key={`new-p-${i}`} className="aspect-square bg-white border border-black relative group overflow-hidden">
              <img src={URL.createObjectURL(file)} className="w-full h-full object-cover" alt="preview" />
              <button 
                type="button" 
                onClick={() => setPreviewImages(prev => prev.filter((_, idx) => idx !== i))}
                className="absolute inset-0 bg-red-600/80 text-white opacity-0 group-hover:opacity-100 flex items-center justify-center font-bold"
              >
                REMOVE
              </button>
            </div>
          ))}

          {previewImages.length + existingPreviewImages.length < 20 && (
            <label className="aspect-square border border-dashed border-black flex items-center justify-center cursor-pointer hover:bg-white transition-colors">
              <input 
                type="file" multiple accept="image/*" className="hidden" 
                onChange={(e) => {
                  const files = Array.from(e.target.files || []);
                  if (previewImages.length + existingPreviewImages.length + files.length > 20) {
                    alert("Maksimal 20 gambar!");
                    return;
                  }
                  setPreviewImages(prev => [...prev, ...files]);
                }}
              />
              <Plus size={16} />
            </label>
          )}
        </div>
      </div>

      <div className="space-y-2">
        <label className="block font-bold text-xs uppercase tracking-wider text-gray-500">Description</label>
        <textarea 
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          className="w-full border border-black p-4 outline-none h-32 font-normal text-sm focus:bg-yellow-50" 
          placeholder="Tell the story of this font..."
        />
      </div>

      <button 
        type="submit"
        disabled={isUploading}
        className="w-full bg-black text-white p-5 font-bold uppercase tracking-[0.2em] text-xs hover:translate-x-[2px] hover:translate-y-[2px] transition-all shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] active:shadow-none active:translate-x-[4px] active:translate-y-[4px] disabled:bg-gray-400 disabled:cursor-not-allowed flex justify-center items-center gap-2"
      >
        {isUploading ? (
          <><Loader2 className="animate-spin" /> Processing...</>
        ) : initialData ? "Update Typeface" : "Save & Publish Product"}
      </button>
    </form>
  );
};

export default FontUploadForm;