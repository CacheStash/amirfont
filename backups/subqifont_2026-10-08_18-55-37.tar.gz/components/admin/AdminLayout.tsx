import React, { useState, useEffect } from 'react';
import { 
  LayoutDashboard, Type, ShoppingCart, LogOut, Tag, 
  Menu, X, Mail, FileText, Power, Loader2, CreditCard, SendHorizontal, Megaphone
} from 'lucide-react';
import { Globe } from 'lucide-react';
import WebAnalytics from './WebAnalytics';
import ProductManager from './ProductManager';
import ContentManager from './ContentManager';
import PromotionsManager from './PromotionsManager'; 
import Orders from './Orders';
import Statistics from './Statistics';
import BroadcastStudio from './BroadcastStudio';
import EmailStudio from './EmailStudio';
import { supabase } from '../../lib/supabase';

const AdminDashboard = () => {
  const [activeTab, setActiveTab] = useState('products');
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);

  // Settings states
  const [isMaintenance, setIsMaintenance] = useState(false);
  const [updatingMaintenance, setUpdatingMaintenance] = useState(false);
  const [isSandbox, setIsSandbox] = useState(false);
  const [updatingSandbox, setUpdatingSandbox] = useState(false);

  useEffect(() => {
    // Concurrent initial data loading for minimal dashboard latency
    Promise.all([fetchUnreadCount(), fetchSiteSettings()]);

    const handleSwitchTab = (e: any) => {
      if (e.detail) setActiveTab(e.detail);
    };
    window.addEventListener('admin-switch-tab', handleSwitchTab);
    return () => window.removeEventListener('admin-switch-tab', handleSwitchTab);
  }, []);

  const fetchSiteSettings = async () => {
    try {
      const { data } = await supabase
        .from('site_settings')
        .select('key, value');
      
      if (data) {
        data.forEach((setting: any) => {
          if (setting.key === 'maintenance_mode') {
            setIsMaintenance(setting.value === true || setting.value === 'true');
          }
          if (setting.key === 'paypal_sandbox_mode') {
            setIsSandbox(setting.value === true || setting.value === 'true');
          }
        });
      }
    } catch (e) {
      console.error('Failed to fetch site settings:', e);
    }
  };

  const handleToggleMaintenance = async () => {
    const nextState = !isMaintenance;
    const confirmMsg = nextState 
      ? 'Enable MAINTENANCE MODE? Public visitors will not be able to access the site (admin only).'
      : 'Disable MAINTENANCE MODE? The site will become publicly accessible again.';
    
    if (!window.confirm(confirmMsg)) return;

    setUpdatingMaintenance(true);
    try {
      const { error } = await supabase
        .from('site_settings')
        .upsert({
          key: 'maintenance_mode',
          value: nextState,
          updated_at: new Date().toISOString()
        });

      if (error) throw error;
      setIsMaintenance(nextState);
    } catch (err: any) {
      alert('Failed to update maintenance mode: ' + err.message);
    } finally {
      setUpdatingMaintenance(false);
    }
  };

  const handleToggleSandbox = async () => {
    const nextState = !isSandbox;
    const confirmMsg = nextState 
      ? 'Enable PAYPAL SANDBOX MODE for testing transactions?'
      : 'Switch to PAYPAL LIVE MODE to accept real customer transactions?';
    
    if (!window.confirm(confirmMsg)) return;

    setUpdatingSandbox(true);
    try {
      const { error } = await supabase
        .from('site_settings')
        .upsert({
          key: 'paypal_sandbox_mode',
          value: nextState,
          updated_at: new Date().toISOString()
        });

      if (error) throw error;
      setIsSandbox(nextState);
    } catch (err: any) {
      alert('Failed to update PayPal mode: ' + err.message);
    } finally {
      setUpdatingSandbox(false);
    }
  };

  const fetchUnreadCount = async () => {
    // Read local session directly to avoid redundant network round-trip of getUser()
    const { data: { session } } = await supabase.auth.getSession();
    const user = session?.user;
    if (!user) return;

    const { count } = await supabase
      .from('font_messages')
      .select('*', { count: 'exact', head: true })
      .eq('recipient_id', user.id)
      .eq('is_read', false);

    setUnreadCount(count || 0);
  };

  const handleTabChange = (tab: string) => {
    setActiveTab(tab);
    setIsMenuOpen(false);
  };

  const handleLogout = async () => {
    const { error } = await supabase.auth.signOut();
    if (error) {
      alert("Failed to sign out: " + error.message);
    } else {
      window.location.href = '/login';
    }
  };

  return (
    <div className="flex flex-col md:flex-row min-h-screen bg-gray-50 text-black font-sans">
      {/* MOBILE ADMIN NAV */}
      <div className="md:hidden flex items-center justify-between px-6 py-4 border-b border-black bg-white sticky top-0 z-50">
        <h1 className="font-black uppercase tracking-tighter text-lg italic">Admin_Panel</h1>
        <button 
          onClick={() => setIsMenuOpen(!isMenuOpen)}
          className="bg-black text-white p-2 border border-black shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] active:shadow-none transition-all"
        >
          {isMenuOpen ? <X size={20} /> : <Menu size={20} />}
        </button>
      </div>

      {/* SIDEBAR */}
      <aside className={`
        fixed md:sticky md:top-0 w-full md:w-64 border-r-0 md:border-r border-black bg-white flex flex-col transition-all duration-300 z-40
        ${isMenuOpen ? 'top-[61px] h-[calc(100vh-61px)] border-b border-black' : 'top-[-100%] md:top-0 h-0 md:h-screen overflow-hidden md:overflow-visible'}
      `}>
        <div className="p-8 border-b border-black hidden md:block">
          <h1 className="font-normal uppercase tracking-tighter text-xl italic">Studio Admin</h1>
        </div>
        
        <nav className="flex-grow p-4 space-y-2">
          <button onClick={() => handleTabChange('stats')} className={`w-full flex items-center gap-3 px-4 py-3 font-bold uppercase text-xs transition-all ${activeTab === 'stats' ? 'bg-black text-white' : 'hover:bg-gray-100'}`}>
            <LayoutDashboard size={18} /> Statistics
          </button>
          <button onClick={() => handleTabChange('broadcast')} className={`w-full flex items-center gap-3 px-4 py-3 font-bold uppercase text-xs transition-all ${activeTab === 'broadcast' ? 'bg-black text-white' : 'hover:bg-gray-100'}`}>
            <Megaphone size={18} /> Broadcast Studio
          </button>
          <button onClick={() => handleTabChange('products')} className={`w-full flex items-center gap-3 px-4 py-3 font-bold uppercase text-xs transition-all ${activeTab === 'products' ? 'bg-black text-white' : 'hover:bg-gray-100'}`}>
            <Type size={18} /> Products
          </button>
          <button onClick={() => handleTabChange('promotions')} className={`w-full flex items-center gap-3 px-4 py-3 font-bold uppercase text-xs transition-all ${activeTab === 'promotions' ? 'bg-black text-white' : 'hover:bg-gray-100'}`}>
            <Tag size={18} /> Promotions
          </button>
          <button onClick={() => handleTabChange('orders')} className={`w-full flex items-center gap-3 px-4 py-3 font-bold uppercase text-xs transition-all ${activeTab === 'orders' ? 'bg-black text-white' : 'hover:bg-gray-100'}`}>
            <ShoppingCart size={18} /> Orders
          </button>
          <button onClick={() => handleTabChange('email_studio')} className={`w-full flex items-center gap-3 px-4 py-3 font-bold uppercase text-xs transition-all ${activeTab === 'email_studio' ? 'bg-black text-white' : 'hover:bg-gray-100'}`}>
            <SendHorizontal size={18} /> Email Studio
          </button>
          <button onClick={() => handleTabChange('content')} className={`w-full flex items-center gap-3 px-4 py-3 font-bold uppercase text-xs transition-all ${activeTab === 'content' ? 'bg-black text-white' : 'hover:bg-gray-100'}`}>
            <FileText size={18} /> Content Mgr
          </button>
       <button onClick={() => handleTabChange('analytics')} className={`w-full flex items-center gap-3 px-4 py-3 font-bold uppercase text-xs transition-all ${activeTab === 'analytics' ? 'bg-black text-white' : 'hover:bg-gray-100'}`}>
            <Globe size={18} /> Web Analytics
          </button>
        </nav>

        {/* Maintenance Toggle, PayPal Mode Toggle & Logout */}
        <div className="p-4 border-t border-black space-y-2">
          {/* Maintenance Switch */}
          <button
            onClick={handleToggleMaintenance}
            disabled={updatingMaintenance}
            className={`w-full flex items-center justify-between px-4 py-2.5 text-[10px] font-black uppercase tracking-wider transition-all border border-black shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] active:shadow-none ${
              isMaintenance 
                ? 'bg-amber-500 text-black' 
                : 'bg-gray-100 text-black hover:bg-gray-200'
            }`}
          >
            <div className="flex items-center gap-2">
              {updatingMaintenance ? (
                <Loader2 size={14} className="animate-spin" />
              ) : (
                <Power size={14} className={isMaintenance ? 'text-black animate-pulse' : 'opacity-40'} />
              )}
              <span>MAINTENANCE</span>
            </div>
            <span className={`px-1.5 py-0.5 text-[9px] font-black border border-black ${
              isMaintenance ? 'bg-black text-white' : 'bg-white text-black'
            }`}>
              {isMaintenance ? 'ON' : 'OFF'}
            </span>
          </button>

          {/* PayPal Sandbox / Live Switch */}
          <button
            onClick={handleToggleSandbox}
            disabled={updatingSandbox}
            className={`w-full flex items-center justify-between px-4 py-2.5 text-[10px] font-black uppercase tracking-wider transition-all border border-black shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] active:shadow-none ${
              isSandbox 
                ? 'bg-[#0070BA] text-white' 
                : 'bg-gray-100 text-black hover:bg-gray-200'
            }`}
          >
            <div className="flex items-center gap-2">
              {updatingSandbox ? (
                <Loader2 size={14} className="animate-spin" />
              ) : (
                <CreditCard size={14} className={isSandbox ? 'text-white' : 'opacity-40'} />
              )}
              <span>PAYPAL MODE</span>
            </div>
            <span className={`px-1.5 py-0.5 text-[9px] font-black border border-black ${
              isSandbox ? 'bg-white text-black' : 'bg-black text-white'
            }`}>
              {isSandbox ? 'SANDBOX' : 'LIVE'}
            </span>
          </button>

          <button onClick={handleLogout} className="w-full flex items-center gap-3 px-4 py-3 font-bold uppercase text-xs hover:bg-red-50 text-red-600 transition-all cursor-pointer">
            <LogOut size={18} /> Logout
          </button>
        </div>
      </aside>

      {/* MAIN CONTENT */}
      <main className="flex-grow p-6 md:p-10 overflow-x-hidden overflow-y-auto w-full">
        {activeTab === 'products' && <ProductManager />}
        {activeTab === 'promotions' && <PromotionsManager onNavigateTab={setActiveTab} />}
        {activeTab === 'content' && <ContentManager />}
        {activeTab === 'stats' && <Statistics />}
        {(activeTab === 'broadcast' || activeTab === 'inbox') && <BroadcastStudio />}
        {activeTab === 'orders' && <Orders />}
        {activeTab === 'email_studio' && <EmailStudio />}
        {activeTab === 'analytics' && <WebAnalytics />}
      </main>
    </div>
  );
};

export default AdminDashboard;