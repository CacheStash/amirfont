import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Search, ArrowRight, ArrowLeft, ShoppingCart, ChevronDown } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { supabase } from '../lib/supabase';
import { User } from '@supabase/supabase-js';

interface NavbarProps {
  onStateChange?: (isActive: boolean) => void;
}


const resolvePreviewUrl = (filename: string) => {
  if (!filename) return null;
  if (filename.startsWith('http')) return filename;
  return `/api/images/${filename}`; 
};

const Navbar: React.FC<NavbarProps> = ({ onStateChange }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [suggestions, setSuggestions] = useState<any[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [user, setUser] = useState<User | null>(null);
  const [isToolsOpen, setIsToolsOpen] = useState(false);
  const [isToolsDrawerOpen, setIsToolsDrawerOpen] = useState(true);
  
  const location = useLocation();
  const { cartCount } = useCart();

  const menuItems = ['Fonts', 'Canvas', 'License', 'About', 'Contact', 'Policy', 'FAQ', 'Tools'];

  const toolLinks = [
    { name: 'Canvas', href: 'https://canvas.subqi.com', badge: 'BETA' },
    { name: 'FontShift', href: 'https://fontshift.subqi.com', badge: 'FREE' },
    { name: 'Fontopsy', href: 'https://fontopsy.subqi.com', badge: 'FREE' },
  ];

  // AUTH LOGIC
  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event: string, session: any) => {
      setUser(session?.user ?? null);
    });

    return () => subscription.unsubscribe();
  }, []);

  const handleLogout = async () => {
     await supabase.auth.signOut();
    setIsOpen(false);
  };

    const handleSearch = async (query: string) => {
    setSearchQuery(query);
    if (query.length < 2) {
      setSuggestions([]);
      return;
    }

    setIsSearching(true);
    try {
      // 1. Cari di tabel Fonts
      const { data, error } = await supabase
        .from('v_global_search')
        .select('*')
        .ilike('search_text', `%${query}%`)
        .order('type', { ascending: true }) // 'font' (f) akan muncul sebelum 'page' (p)
        .limit(10);
      
      if (error) throw error;
      setSuggestions(data || []);
    } catch (err) {
      console.error("Search Fail:", err);
    } finally {
      setIsSearching(false);
    }
  };

  // Reset search saat overlay ditutup
  useEffect(() => {
    if (!isSearchOpen) {
      setSearchQuery('');
      setSuggestions([]);
    }
  }, [isSearchOpen]);

   
  // OVERLAY LOGIC
  useEffect(() => {
    if (onStateChange) {
      onStateChange(isOpen || isSearchOpen);
    }
  }, [isOpen, isSearchOpen, onStateChange]);

  useEffect(() => {
    setIsOpen(false);
    setIsSearchOpen(false);
  }, [location]);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav className={`w-full sticky top-0 z-[100] transition-all duration-300 mb-[-1px] ${
      isScrolled ? 'backdrop-blur-xl bg-[#EDEBE6]/70' : 'bg-[#EDEBE6]'
    }`}>
      
      {/* 1. MAIN BAR */}
      <div className={`w-full flex justify-between items-center h-14 md:h-16 px-0 relative z-[130] border-b border-black transition-colors duration-300 ${
        (isOpen || isSearchOpen) ? 'bg-[#EDEBE6]' : 'bg-transparent'
      }`}>
        
        {/* Left: Toggle & Logo */}
        <div className="flex items-center gap-2 md:gap-3 lg:gap-4 h-full border-r border-black px-3 md:px-4 lg:px-8 flex-1 md:flex-none md:w-[220px] lg:w-[320px] xl:w-[450px] min-w-0">
          <button 
            onClick={() => { setIsOpen(!isOpen); setIsSearchOpen(false); }}
            className="p-1 hover:bg-black hover:text-white transition-colors border border-black md:border-transparent md:hover:border-black shrink-0"
          >
            {isOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
          <Link to="/" className="flex items-center h-full hover:opacity-70 transition-opacity">
            <img 
              src="/Logo.png" 
              alt="Subqi Studio" 
              className="h-6 md:h-7 lg:h-8 w-auto object-contain" 
            />
          </Link>
        </div>

        {/* Center: Quick Links */}
        <div className="hidden md:flex items-center gap-8 lg:gap-14 xl:gap-16 font-mono text-xs font-bold uppercase tracking-widest px-2 lg:px-6 h-full flex-1 justify-center">
          <Link to="/fonts" className="hover:text-[#FF5C00] transition-colors py-2">
            FONTS
          </Link>
          <Link to="/canvas" className="flex items-center gap-1.5 hover:text-[#FF5C00] transition-colors py-2">
            <span>CANVAS</span>
            <span className="bg-[#FF5C00] text-black text-[7px] font-black px-1 py-0 h-3 leading-none flex items-center rounded-[2px] self-start -mt-0.5">BETA</span>
          </Link>

          {/* Tools Dropdown */}
          <div 
            className="relative h-full flex items-center"
            onMouseEnter={() => setIsToolsOpen(true)}
            onMouseLeave={() => setIsToolsOpen(false)}
          >
            <button
              type="button"
              onClick={() => setIsToolsOpen(prev => !prev)}
              className="hover:text-[#FF5C00] transition-colors py-2 flex items-center gap-1.5 cursor-pointer select-none uppercase tracking-widest font-bold"
            >
              <span>TOOLS</span>
              <ChevronDown size={11} className={`transition-transform duration-200 ${isToolsOpen ? 'rotate-180 text-[#FF5C00]' : ''}`} />
            </button>

            {isToolsOpen && (
              <div className="absolute top-full left-1/2 -translate-x-1/2 w-44 bg-[#EDEBE6] border-x border-b border-black shadow-2xl py-1.5 px-1 z-[140] flex flex-col gap-1">
                {toolLinks.map(tool => (
                  <a
                    key={tool.name}
                    href={tool.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    onClick={() => setIsToolsOpen(false)}
                    className="px-3 py-2 hover:bg-black hover:text-white transition-colors flex items-center justify-between text-[10px] font-bold tracking-widest uppercase"
                  >
                    <span>{tool.name}</span>
                    <span className="bg-[#FF5C00] text-black text-[7px] px-1 py-0 h-3 leading-none flex items-center rounded-[2px] font-black">
                      {tool.badge}
                    </span>
                  </a>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Right: Search & Cart */}
        <div className="flex items-center justify-end gap-1.5 md:gap-2.5 lg:gap-4 h-full border-l-0 md:border-l border-black px-2.5 md:px-4 lg:px-8 shrink-0 bg-inherit">
            <button
              onClick={() => { setIsSearchOpen(!isSearchOpen); setIsOpen(false); }}
              className={`p-1 transition-colors border border-transparent ${isSearchOpen ? 'bg-black text-white' : 'hover:bg-black hover:text-white hover:border-black'}`}
            >
               {isSearchOpen ? <X size={20} /> : <Search size={20} />}
            </button>

            <div className="flex items-center border border-black h-9 md:h-10 font-bold text-xs md:text-sm uppercase bg-transparent overflow-visible">
              {/* Part 1: Account / Login Trigger */}
              <div className="relative h-full group/acc border-r border-black">
                {user ? (
                  <>
                    <button className="h-full px-2.5 md:px-3 lg:px-4 hover:bg-black hover:text-white transition-colors">
                      ACCOUNT
                    </button>
                    {/* Account Dropdown Menu (Appears on Hover) */}
                    <div className="absolute top-full right-[-1px] w-48 bg-[#EDEBE6] border-x border-b border-black hidden group-hover/acc:block z-[140] animate-in slide-in-from-top-1 duration-200">
                      <Link 
                        to="/user/dashboard" 
                        className="flex items-center justify-between p-4 border-b border-black hover:bg-black hover:text-white transition-all group/item"
                      >
                        <span>DASHBOARD</span>
                        <ArrowRight size={16} className="opacity-0 -translate-x-2 group-hover/item:opacity-100 group-hover/item:translate-x-0 transition-all" />
                      </Link>
                      <button 
                        onClick={handleLogout}
                        className="w-full flex items-center justify-between p-4 hover:bg-black hover:text-white transition-all group/item text-left"
                      >
                        <span>LOGOUT</span>
                        <ArrowRight size={16} className="opacity-0 -translate-x-2 group-hover/item:opacity-100 group-hover/item:translate-x-0 transition-all" />
                      </button>
                    </div>
                  </>
                ) : (
                  <Link to="/user/auth" className="h-full px-2.5 md:px-3 lg:px-4 flex items-center hover:bg-black hover:text-white transition-colors">
                    LOGIN
                  </Link>
                )}
              </div>

              {/* Part 2: Cart Icon Section */}
              <Link to="/cart" className="h-full px-2.5 md:px-3 flex items-center relative hover:bg-black hover:text-white transition-colors group">
                <ShoppingCart size={20} className="shrink-0" />
                {cartCount > 0 && (
                  <span className="absolute -top-2 -right-2 bg-black text-[#EDEBE6] text-[10px] w-5 h-5 flex items-center justify-center border border-[#EDEBE6] font-bold">
                    {cartCount}
                  </span>
                )}
              </Link>
            </div>
        </div>
      </div>

      {/* 2. SEARCH OVERLAY */}
      <div className={`fixed inset-0 top-0 w-full h-fit bg-[#EDEBE6] z-[120] border-b border-black transition-transform duration-700 cubic-bezier(0.85, 0, 0.15, 1) ${
        isSearchOpen ? 'translate-y-0' : '-translate-y-full'
      }`}>
          <div className="h-14 md:h-16 w-full border-b border-black"></div>
          <div className="p-4 md:p-10 max-w-full">
              <div className="flex items-center w-full gap-0 border border-black bg-transparent overflow-hidden">
                  <div className="p-4 border-r border-black flex items-center justify-center bg-transparent">
                      <Search size={24} className="opacity-50"/>
                  </div>
                  <input 
                    type="text" 
                    value={searchQuery}
                    onChange={(e) => handleSearch(e.target.value)}
                    placeholder="TYPE TO SEARCH ANYTHING AT THIS SITE..." 
                    className="w-full p-4 md:text-2xl font-normal uppercase bg-transparent outline-none placeholder:text-gray-400"
                    autoFocus={isSearchOpen}
                  />
                  <button className="p-4 px-6 hover:bg-black hover:text-white border-l border-black transition-colors md:text-xl font-bold">
                      {isSearching ? '...' : 'SEARCH'}
                  </button>
              </div>

              {/* AUTO-SUGGESTION DROPDOWN */}
              {suggestions.length > 0 && (
                <div className="border-x border-b border-black bg-white divide-y divide-black/10 max-h-[60vh] overflow-y-auto">
                  {suggestions.map((item, index) => (
                    <Link
                      key={index}
                      to={item.path}
                      className="flex items-center justify-between p-4 md:px-8 hover:bg-black hover:text-white transition-all group"
                    >
                      <div className="flex flex-col">
                        <span className="text-[10px] font-black opacity-40 uppercase tracking-widest">
                          {item.type === 'page' ? item.category : item.type}
                        </span>
                        <span className="text-xl md:text-3xl font-normal uppercase tracking-tighter leading-none">
                          {item.title}
                        </span>
                        {item.type === 'font' && item.font_images?.[0] && (
                          <div className="mt-4 flex gap-2">
                            {item.font_images.slice(0, 3).map((img: string, i: number) => (
                              <div key={i} className="border border-black/10 bg-[#f9f9f9] p-1 w-fit group-hover:border-white transition-colors">
                                <img 
                                  src={resolvePreviewUrl(img) || ''} 
                                  alt={`${item.title} preview ${i}`} 
                                  className="h-12 md:h-16 w-auto object-contain grayscale-0 group-hover:grayscale transition-all duration-500" 
                                />
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                      <ArrowRight size={24} className="opacity-0 -translate-x-4 group-hover:opacity-100 group-hover:translate-x-0 transition-all" />
                    </Link>
                  ))}
                </div>
              )}
              
          </div>
      </div>

      {/* 3. NAVIGATION MENU OVERLAY */}
      <div className={`fixed inset-0 top-0 w-full h-screen bg-[#EDEBE6] z-[110] transition-transform duration-700 cubic-bezier(0.85, 0, 0.15, 1) flex flex-col ${
        isOpen ? 'translate-y-0' : '-translate-y-full'
      }`}>
          <div className="h-14 md:h-16 w-full border-b border-black bg-[#EDEBE6] flex-shrink-0"></div>

          <div className="flex-1 overflow-y-auto pt-0"> 
              {/* FIXED: Menghapus h-full pada mobile agar tidak ada gap antar blok menu */}
              <div className="grid grid-cols-1 lg:grid-cols-2 w-full lg:h-full border-black">
                  
                  {/* Column 1: Items 1-4 */}
                  <div className="flex flex-col border-r-0 lg:border-r border-black">
                      {menuItems.slice(0, 4).map((item) => (
                        <Link 
                          key={item} 
                          to={`/${item.toLowerCase()}`}
                         className="text-3xl lg:text-6xl font-normal uppercase tracking-tighter px-3 lg:px-8 py-6 lg:py-10 border-b border-black hover:bg-black hover:text-white transition-all flex justify-between items-center group"
                        >
                          <span className="flex items-center gap-3">
                            <span>{item}</span>
                            {item === 'Canvas' && (
                              <span className="bg-[#FF5C00] text-black text-[9px] font-black px-1.5 py-0 h-3.5 leading-none flex items-center rounded-[2px] tracking-normal group-hover:bg-white self-start">
                                BETA
                              </span>
                            )}
                          </span>
                          <ArrowRight size={32} className="opacity-0 -translate-x-4 group-hover:opacity-100 group-hover:translate-x-0 transition-all" />
                        </Link>
                      ))}
                  </div>

                  {/* Column 2: Items 5-7 + Auth Button */}
                  <div className="flex flex-col">
                      {menuItems.slice(4).map((item) => {
                        if (item === 'Tools') {
                          return (
                            <div key="Tools" className="border-b border-black">
                              <button
                                type="button"
                                onClick={() => setIsToolsDrawerOpen(prev => !prev)}
                                className="w-full text-3xl lg:text-6xl font-normal uppercase tracking-tighter px-3 lg:px-8 py-6 lg:py-10 hover:bg-black hover:text-white transition-all flex justify-between items-center group cursor-pointer text-left"
                              >
                                <span className="flex items-center gap-3">
                                  <span>Tools</span>
                                  <ChevronDown size={28} className={`transition-transform duration-300 ${isToolsDrawerOpen ? 'rotate-180' : ''}`} />
                                </span>
                                <span className="text-xs font-mono tracking-widest text-[#FF5C00] font-bold">
                                  3 APPS
                                </span>
                              </button>
                              {isToolsDrawerOpen && (
                                <div className="bg-black/5 divide-y divide-black/10 border-t border-black">
                                  {toolLinks.map(tool => (
                                    <a
                                      key={tool.name}
                                      href={tool.href}
                                      target="_blank"
                                      rel="noopener noreferrer"
                                      onClick={() => setIsOpen(false)}
                                      className="px-6 lg:px-12 py-4 hover:bg-black hover:text-white transition-all flex justify-between items-center group/tool"
                                    >
                                      <span className="flex items-center gap-3 font-mono text-sm lg:text-lg font-bold tracking-widest uppercase">
                                        <span>{tool.name}</span>
                                        <span className="bg-[#FF5C00] text-black text-[8px] font-black px-1.5 py-0.5 rounded-[2px]">
                                          {tool.badge}
                                        </span>
                                      </span>
                                      <ArrowRight size={18} className="opacity-0 -translate-x-2 group-hover/tool:opacity-100 group-hover/tool:translate-x-0 transition-all" />
                                    </a>
                                  ))}
                                </div>
                              )}
                            </div>
                          );
                        }

                        return (
                          <Link 
                            key={item} 
                            to={`/${item.toLowerCase()}`}
                            className="text-3xl lg:text-6xl font-normal uppercase tracking-tighter px-3 lg:px-8 py-6 lg:py-10 border-b border-black hover:bg-black hover:text-white transition-all flex justify-between items-center group"
                          >
                            <span>{item}</span>
                            <ArrowRight size={32} className="opacity-0 -translate-x-4 group-hover:opacity-100 group-hover:translate-x-0 transition-all" />
                          </Link>
                        );
                      })}

                      
                      
                      <div className="flex-1 border-b border-black md:border-b-0"></div>
                  </div>
              </div>

    
          </div>
      </div>
    </nav>
  );
};

export default Navbar;